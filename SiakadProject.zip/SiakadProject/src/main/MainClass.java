/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import entitas.Mahasiswa;
import entitas.MahasiswaDN;
import entitas.MahasiswaLN;
import entitas.PegawaiLN;

/**
 *
 * @author ahnaffaiz
 */
public class MainClass {
    public static void main(String[] args) {
        
        /*Mahasiswa mhs1 = new Mahasiswa("T0215001", "Budi"); 
        mhs1.setBeratBadan(50);
        mhs1.setTinggiBadan(170);
        mhs1.setGender('L');
        mhs1.cetakData();
        
        
        MahasiswaDN mhsDN1 = new MahasiswaDN("M0218002", "Amir");
        mhsDN1.setNoKTP(("1311320001"));
        mhsDN1.setBeratBadan(54);
        mhsDN1.setTinggiBadan(165);
        mhsDN1.setGender('L');
        mhsDN1.cetakData();
        
        MahasiswaLN mhsLN1 = new MahasiswaLN("K0118001", "Salma");
        mhsLN1.setNoPasport(("1311320001"));
        mhsLN1.setBeratBadan(54);
        mhsLN1.setTinggiBadan(165);
        mhsLN1.setGender('L');
        mhsLN1.cetakData();
        */
        PegawaiLN pgwLN1 = new PegawaiLN("K01", "Joko");
        pgwLN1.setGolongan("A");
        pgwLN1.setJumlahAnak(5);
        pgwLN1.setMasakerja(10);
        pgwLN1.setStatusNikah('Y');
        pgwLN1.setNoPasport("1311320012");
        pgwLN1.setUsia(20);
        pgwLN1.cetakData();
    }
    
}
