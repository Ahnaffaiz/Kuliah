/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entitas;

/**
 *
 * @author ahnaffaiz
 */
public class PegawaiLN extends Pegawai{
    
    //atributte
    private String noPasport;

    public PegawaiLN(String kodePegawai, String namaPegawai) {
        super(kodePegawai, namaPegawai);
    }
    public PegawaiLN(String kodePegawai, String namaPegawai, int usia){
        super(kodePegawai, namaPegawai, usia);
    }
    
    public PegawaiLN(String kodePegawai, String namaPegawai, int usia, String gol){
        super(kodePegawai, namaPegawai, usia, gol);
    }
    
    public PegawaiLN(String kodePegawai, String namaPegawai, int usia, String gol, int masaKerja){
        super(kodePegawai, namaPegawai, usia, gol, masaKerja);
    }
    
    public PegawaiLN(String kodePegawai, String namaPegawai, int usia, String gol, int masaKerja, char statusNikah){
        super(kodePegawai, namaPegawai, usia, gol, masaKerja, statusNikah);
    }
    
    public PegawaiLN(String kodePegawai, String namaPegawai, int usia, String gol, int masaKerja
            ,char statusNikah, int jumlahAnak){
        super(kodePegawai, namaPegawai, usia, gol, masaKerja, statusNikah, jumlahAnak);
    }
    
    public void setNoPasport(String x){
        this.noPasport = x;
    }
    
    public String getNoPasport(){
        return this.noPasport;
    }
    
    public int getGajiPokok(){
        int masaKerja = this.masaKerja;
        String Gol = this.golongan;
        int gajiPokok = 0;
        if (masaKerja < 5 && masaKerja>0){
            if("A".equals(Gol)){
                gajiPokok = 2500000;
            }
            if("B".equals(Gol)){
                gajiPokok = 3500000;
            }
            if("C".equals(Gol)){
                gajiPokok = 5000000;
            }
            if("D".equals(Gol)){
                gajiPokok = 6500000;
            }
        }
        else if(masaKerja>=5){
            if("A".equals(Gol)){
                gajiPokok = 3000000;
            }
            if("B".equals(Gol)){
                gajiPokok = 4500000;
            }
            if("C".equals(Gol)){
                gajiPokok = 6000000;
            }
            if("D".equals(Gol)){
                gajiPokok = 7500000;
            }
        }
        return gajiPokok;
        
    }
    
    /**
     *
     * @return
     */
    
    //methods untuk mencari tunjangan nikah
    public double getTunjPasangan() {
        double tunjangan = 0;
        char statusNikah = this.statusMenikah;
        if ( statusNikah== 'Y') {
            int gajiPokok = this.getGajiPokok();
            tunjangan = 0.08 * gajiPokok;
        } else 
            if (statusNikah == 'N')  {
                System.out.println("Tidak ada tunjangan nikah");
        }
        return tunjangan;
        
    }
    
    //methods untuk mencari tunjangan anak
    public double getTunjAnak() {
        char statusNikah = this.statusMenikah;
        int jumlahAnak = this.getJumlahAnak();
        double tunjangan = 0;
        int gajiPokok = this.getGajiPokok();
        if (statusNikah == 'Y') {
            if (jumlahAnak > 0){
                tunjangan = 0.05 * gajiPokok;
            } else {
                System.out.println("Tidak ada tunjangan anak");
            }
            
        } else {
            System.out.println("Tidak ada tunjangan anak");
        }
        
        return tunjangan;
    }
    
    public void cetakData(){
        System.out.println("----------------------");
        System.out.println("Data Pegawai");
        System.out.println("Kode Pegawai    : " + this.getKodePegawai());
        System.out.println("Nama            : " + this.getNama());
        System.out.println("No Pasport      : " + this.getNoPasport());
        System.out.println("Usia            : " + this.getUsia());
        System.out.println("Masa Kerja      : " + this.getMasaKerja());
        System.out.println("Golongan        : " + this.getGolongan());
        System.out.println("Status Menikah  : " + this.getStatusMenikah());
        System.out.println("Jumlah Anak     : " + this.getJumlahAnak());
        System.out.println("Gaji Pokok      : " + this.getGajiPokok());
        System.out.println("Tunj Nikah      : " + this.getTunjPasangan());
        System.out.println("Tunj Anak       : " + this.getTunjAnak());
        System.out.println("Total gaji      : " + this.getTotalGaji());
    }
}
