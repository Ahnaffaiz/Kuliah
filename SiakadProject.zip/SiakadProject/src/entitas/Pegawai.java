/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entitas;

/**
 *
 * @author Ahnaffaiz
 */
public class Pegawai {
    
    //atribute
    String kodePegawai, nama, golongan;
    int usia, masaKerja, jumlahAnak;
    char statusMenikah;
    
    //constructor
    public Pegawai(String kodePegawai, String namaPegawai){
        this.kodePegawai = kodePegawai;
        this.nama = namaPegawai;
        this.usia = 0;
        this.masaKerja = 0;
        this.golongan = "A";
        this.statusMenikah = 'N';
        this.jumlahAnak = 0;
    }
    
    public Pegawai(String kodePegawai, String namaPegawai, int usia){
        this.kodePegawai = kodePegawai;
        this.nama = namaPegawai;
        this.usia = usia;
        this.golongan ="A";
        this.masaKerja = 0;
        this.statusMenikah='N';
        this.jumlahAnak = 0;
    }
    
    public Pegawai(String kodePegawai, String namaPegawai, int usia, String gol){
        this.kodePegawai = kodePegawai;
        this.nama = namaPegawai;
        this.usia = usia;
        this.golongan = gol;
        this.masaKerja = 0;
        this.statusMenikah = 'N';
        this.jumlahAnak = 0;
    }
    
    public Pegawai(String kodePegawai, String namaPegawai, int usia, String gol, int masaKerja){
        this.kodePegawai = kodePegawai;
        this.nama = namaPegawai;
        this.usia = usia;
        this.golongan = gol;
        this.masaKerja = masaKerja;
        this.statusMenikah = 'N';
        this.jumlahAnak = 0;
    }
    
    public Pegawai(String kodePegawai, String namaPegawai, int usia, String gol, int masaKerja, char statusNikah){
        this.kodePegawai = kodePegawai;
        this.nama = namaPegawai;
        this.usia = usia;
        this.golongan = gol;
        this.masaKerja = masaKerja;
        this.statusMenikah = statusNikah;
        this.jumlahAnak = 0;
    }
    
    public Pegawai(String kodePegawai, String namaPegawai, int usia, String gol, int masaKerja
            ,char statusNikah, int jumlahAnak){
        this.kodePegawai = kodePegawai;
        this.nama = namaPegawai;
        this.usia = usia;
        this.golongan = gol;
        this.masaKerja = 0;
        this.statusMenikah = statusNikah;
        this.jumlahAnak = jumlahAnak;
    }
    
    
    
    
    
    //methods untuk untuk memberi nilai usia, gol, masakerja, statusmenikah dan jumlah anak
    
    //methods memberi nilai usia
    public void setUsia(int usia){
        if (usia>0){
            this.usia = usia;
        }
        else{
            System.out.println("Usia Tidak valid");
        }
    }
    
    //methods untuk memberi nilai golongan
    public void setGolongan(String gol){
        if ("A".equals(gol) || "B".equals(gol) || "C".equals(gol) || "D".equals(gol)){
            this.golongan = gol;
        }
        else{
            System.out.println("Nilai Golongan Tidak valid");
        }
    }
    
    //methods untuk memberi nilai int masa kerja
    
    public void setMasakerja(int masaKerja){
        if (masaKerja>0){
            this.masaKerja = masaKerja;
        }
        else{
            System.out.println("Nilai Masa Kerja Tidak valid");
        }
    }
    
    //methods untuk memberi nilai int masa kerja
    public void setMasakerja(double masaKerja){
        if (masaKerja>0.0){
            this.masaKerja = (int) masaKerja;
        } else {
            System.out.println("Masa Kerja Tidak Valid");
        }
    }
    
    //methods untuk memasukkan nilai status menikah
    public void setStatusNikah(char status){
        if (status == 'Y'){
            this.statusMenikah = status;
        }
        else if (status =='N') {
            this.statusMenikah = status;
        }
        else{
            System.out.println("Status Tidak valid");
        }
    }
    
    //methods untuk memasukkan jumlah anak
    public void setJumlahAnak(int anak){
        if (anak >= 0){
            this.jumlahAnak = anak;
        }
        else{
            System.out.println("Jumlah anak tidak valid");
        }
    }
    
    //methods untuk mendapatkan gaji pokok pegawai
    public int getGajiPokok(){
        int masaKerja = this.masaKerja;
        String Gol = this.golongan;
        int gajiPokok = 0;
        if (masaKerja < 10 && masaKerja>0){
            if("A".equals(Gol)){
                gajiPokok = 3000000;
            }
            if("B".equals(Gol)){
                gajiPokok = 4500000;
            }
            if("C".equals(Gol)){
                gajiPokok = 6000000;
            }
            if("D".equals(Gol)){
                gajiPokok = 7500000;
            }
        }
        else if(masaKerja>=10){
            if("A".equals(Gol)){
                gajiPokok = 4000000;
            }
            if("B".equals(Gol)){
                gajiPokok = 5500000;
            }
            if("C".equals(Gol)){
                gajiPokok = 7000000;
            }
            if("D".equals(Gol)){
                gajiPokok = 8500000;
            }
        }
        return gajiPokok;
        
    }
    
    //membuat method untuk menghitung tunjangan
    public double getTunjPasangan() {
        double tunjangan = 0;
        char statusNikah = this.statusMenikah;
        if ( statusNikah== 'Y') {
            int gajiPokok = this.getGajiPokok();
            tunjangan = 0.1 * gajiPokok;
        } else 
            if (statusNikah == 'N')  {
                System.out.println("Tidak ada tunjangan nikah");
        }
        return tunjangan;
        
    }
    
    //membuat methods untuk menghitung tunjangan anak
    public double getTunjAnak() {
        char statusNikah = this.statusMenikah;
        int jumlahAnak = this.getJumlahAnak();
        double tunjangan = 0;
        int gajiPokok = this.getGajiPokok();
        if (statusNikah == 'Y') {
            if (jumlahAnak > 0){
                tunjangan = 0.07 * gajiPokok;
            } else {
                System.out.println("Tidak ada tunjangan anak");
            }
            
        } else {
            System.out.println("Tidak ada tunjangan anak");
        }
        
        return tunjangan;
    }
    
    //methods untuk menghitung total gaji
    public double getTotalGaji() {
        double totalGaji = this.getGajiPokok() + this.getTunjPasangan() + this.getTunjAnak();
        return totalGaji;
    }
    
    
    /*
    1.	Buatlah method baru di class ‘Pegawai’, 
    yaitu cetakData() untuk mencetak kodePegawai, nama, 
    usia, golongan, masa kerja, status menikah, jml anak, 
    gaji pokok*/

    public String getKodePegawai() {
        return kodePegawai;
    }

    public String getNama() {
        return nama;
    }

    public String getGolongan() {
        return golongan;
    }

    public int getUsia() {
        return usia;
    }

    public int getMasaKerja() {
        return masaKerja;
    }

    public int getJumlahAnak() {
        return jumlahAnak;
    }

    public char getStatusMenikah() {
        return statusMenikah;
    }
    
    public void cetakData(){
        System.out.println("----------------------");
        System.out.println("Data Pegawai");
        System.out.println("Kode Pegawai    : " + this.getKodePegawai());
        System.out.println("Nama            : " + this.getNama());
        System.out.println("Usia            : " + this.getUsia());
        System.out.println("Masa Kerja      : " + this.getMasaKerja());
        System.out.println("Golongan        : " + this.getGolongan());
        System.out.println("Status Menikah  : " + this.getStatusMenikah());
        System.out.println("Jumlah Anak     : " + this.getJumlahAnak());
        System.out.println("Gaji Pokok      : " + this.getGajiPokok());
        System.out.println("tunj Nikah      : " + this.getTunjPasangan());
        System.out.println("Tunj Anak       : " + this.getTunjAnak());
        System.out.println("Total gaji      : " + this.getTotalGaji());
    }
    
    
}
