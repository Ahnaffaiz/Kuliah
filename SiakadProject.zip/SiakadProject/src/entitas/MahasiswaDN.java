/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entitas;

/**
 *
 * @author ahnaffaiz
 */
public class MahasiswaDN extends Mahasiswa{
    
    //atribute
    private String noKTP;

    //constructor
    public MahasiswaDN(String nim, String nama) {
        super(nim, nama);
    }
    
    //methods
    public void setNoKTP(String x){
        this.noKTP = x;
    }
    
    public String getNoKTP(){
        return noKTP;
    }
    
    public void cetakData(){
        System.out.println("-----------------------");
        System.out.println("Data Mahasiswa");
        System.out.println("-----------------------");
        System.out.println("NIM         : " + this.nim);
        System.out.println("No KTP      : " + this.getNoKTP());
        System.out.println("Nama        : " + this.nama);
        System.out.println("Angkatan    : " + this.getAngkatan());
        System.out.println("Fakultas    : " + this.getFakultas());
        System.out.println("Jurusan     : " + this.getJurusan());
        System.out.println("Berat (kg)  : " + this.getBeratBadan());
        System.out.println("Tinggi (cm) : " + this.getTinggiBadan());
        System.out.println("Gender      : " + this.getGender());
    }

}
