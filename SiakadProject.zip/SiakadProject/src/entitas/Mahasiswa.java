/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entitas;

/**
 *
 * @author Ahnaffaiz
 */
public class Mahasiswa {
    
    //atribute
    public String nama, nim;
    public String angkatan, fakultas, jurusan;
    private int beratBadan, tinggiBadan;
    public char gender;

    //constructor
    //dan memberi nilai default 0 pada beratBadan dan tinggiBadan
    public Mahasiswa(String nim, String nama){
        this.nim = nim;
        this.nama = nama;
        this.beratBadan = 0;
        this.tinggiBadan = 0;
        }

    
    //memberi nilai default 0 pada tinggiBadan
    public void Mahasiswa( String nim, String nama, int beratBadan){
        this.nim = nim;
        this.nama = nama;
        this.beratBadan = beratBadan;
        this.tinggiBadan = 0;
    }
    
    //memberi nilai penuh
    public void Mahasiswa( String nim, String nama, int beratBadan, int tinggiBadan){
        this.nim = nim;
        this.nama = nama;
        this.beratBadan = beratBadan;
        this.tinggiBadan = tinggiBadan;
    }
    
    
    
    //agar nilai beratbadan valid
    //menerima nilai beratBadan int
    public void setBeratBadan(int bb) {
        if (bb>0){
            beratBadan=bb;
        } else {
            System.out.println("Tidak Valid");
        }
    }

    
    //menerima nilai beratBadan double
    public void setBeratBadan(double bb){
        if (bb>0.) {
            this.beratBadan= (int) bb;
        } else {
            System.out.println("Berat badan tidak valid");
        }
    }
    
    

    public double getTinggiBadan() {
        return tinggiBadan;
    }

    public double getBeratBadan() {
        return beratBadan;
    }
    
    
    
    
    //agar nilai tinggibadan valid
    public void setTinggiBadan(int tb) {
        if (tb>0){
            tinggiBadan=tb;
        } else {
            System.out.println("Tidak Valid");
        }
    }
    
    public void setTinggiBadan(double tb) {
        if (tb>0.) {
            tinggiBadan = (int) tb;
        } else {
            System.out.println("Tinggi badan tidak valid");
        }
    }
    
    //agar nilai gendervalid
    public void setGender(char g)
    {        
        if (g=='L'){
            this.gender='L';
        } else if(g=='P') {
            this.gender='P';
        } else {
            System.out.println("Tidak valid");
        }
        
    }
    
    
    
    
    /**
     * menentukan fakultas sesuai kode
     * T Teknik
     * K Keguruan
     * M mipa
     * @param f
     * @return 
     */
    
    public String getFakultas(){
        String f = this.nim;
        switch (f.substring(0,1)) {
        //untuk mendapatkan nilai dari index ke 0
            case "T":
                this.fakultas = "Teknik";
                break;
            case "K":
                this.fakultas = "Keguruan dan Ilmu Pendidikan";
                break;
            case "M":
                this.fakultas = "MIPA";   
                break;
            default:
                System.out.println("Kode Tidak Valid");
                break;
        }
        return this.fakultas;
    }
    
    /**
     * menentukan jurusan sesuai kode index ke-1 & ke-2
     * T01 = Teknik mesin
     * T02 = teknik Sipil
     * K01 = Pendidikan TIK
     * K02 = Pendidikan matematika
     * M01 = Matematika
     * M02 = Fisika
     * @param f
     */
    
    /**
     * menentukan jurusan sesuai kode index ke-1 &; ke-2
 T01 = Teknik mesin
 T02 = teknik Sipil
 K01 = Pendidikan TIK
 K02 = Pendidikan matematika
 M01 = Matematika
 M02 = Fisika
     * @return
     */
    
    public String getJurusan(){
        String f = this.nim;
        if (null != f.substring(0,1)) 
        switch (f.substring(0,1)) {
        //untuk mendapatkan nilai dari index ke 0
            case "T":
                 if (null != f.substring(1,3))switch (f.substring(1,3)) {
            case "01":
                this.jurusan = "Teknik Mesin";
                break;
            case "02":
                this.jurusan = "Teknik Sipil";
                break;
            default:
                System.out.println("NIM Tidak Valid");
                break;
        }  break;
            case "K":
                 if (null != f.substring(1,3))switch (f.substring(1,3)) {
            case "01":
                this.jurusan = "Pendidikan TIK";
                break;
            case "02":
                this.jurusan = "Pendidikan Matematika";
                break;
            default:
                System.out.println("NIM Tidak Valid");
                break;
        }  break;
            case "M":
                  if (null == f.substring(1,3)) {
        } else {
                      switch (f.substring(1,3)) {
                          case "01":
                              this.jurusan = "Matematika";
                              break;
                          case "02":
                              this.jurusan = "Fisika";
                              break;
                          default:
                              System.out.println("NIM Tidak Valid");
                              break;
                      }
        } break;
            default:
                this.jurusan = "-";
                System.out.println("Kode Tidak Valid");   
                break;
        }
        return this.jurusan;
    }
    
    public String getAngkatan(){
        String angkatan = this.nim;
        this.angkatan = angkatan.substring(3, 5);
        return this.angkatan;
    }

    public String getNim() {
        return nim;
    }
    
    
    public char getGender(){
        return gender;
    }
    
    public void cetakData(){
        System.out.println("----------------------------");
        System.out.println("Data Mahasiswa: ");
        System.out.println("----------------------------");
        System.out.println("NIM         : " + this.nim);
        System.out.println("Nama        : " + this.nama);
        System.out.println("Angkatan    : " + this.getAngkatan());
        System.out.println("Fakultas    : " + this.getFakultas());
        System.out.println("Jurusan     : " + this.getJurusan());
        System.out.println("Berat (KG)  : " + this.getBeratBadan());
        System.out.println("Tinggi (cm) : " + this.getTinggiBadan());
        System.out.println("Gender      : " + this.getGender());
    }
    
}
